# Gloves for CS:GO Community Servers

[![](https://img.shields.io/github/license/kgns/gloves.svg?style=flat-square)](https://github.com/kgns/gloves/blob/master/LICENSE)
[![Build Status](https://build.kgns.dev/job/csgo-gloves/badge/icon?style=flat-square)](https://build.kgns.dev/job/csgo-gloves)
[![GitHub Downloads](https://img.shields.io/github/downloads/kgns/gloves/total.svg?style=flat-square)](https://github.com/kgns/gloves/releases/latest)

AlliedModders forum link:

- https://forums.alliedmods.net/showthread.php?t=299977

--------------------

If you want to donate, I'd appreciate it:

https://steamcommunity.com/tradeoffer/new/?partner=37011238&token=yGo05pTn
